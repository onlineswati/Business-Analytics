package manager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class TableauKey extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public TableauKey() {
		super();
	}

	public static Properties propTab = new Properties();

	static {
		disableSslVerification();
	}

	private static void disableSslVerification() {
		try {
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(X509Certificate[] certs,
						String authType) {
				}

				public void checkServerTrusted(X509Certificate[] certs,
						String authType) {
				}
			} };

			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection
					.setDefaultSSLSocketFactory(sc.getSocketFactory());

			// Create all-trusting host name verifier
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			};

			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (KeyManagementException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();

		// for localhost testing only

		try {
			// String proj_Dir = System.getProperty("user.dir");
			// String location = System.getenv("HMROOT");
			// System.out.println(location);
			// BufferedReader idFormatReader = new BufferedReader(new
			// FileReader(
			// location + "//tableau//config//TableauSettings.properties"));
			// System.out.println(proj_Dir);
			BufferedReader idFormatReader = new BufferedReader(new FileReader(
					new File("D:\\config\\TableauSettings.properties")));
			while ((idFormatReader.readLine()) != null) {
				propTab.load(idFormatReader);
			}
			idFormatReader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<String> userLoggedIn = new ArrayList<String>();
		this.getServletContext().setAttribute("usersLoggedIn", userLoggedIn);
	}

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		final String user = request.getParameter("username");
		final String password = request.getParameter("password");

		request.setAttribute("user", user);
		PrintWriter out = response.getWriter();

		if (this.getServletContext().getAttribute("usersLoggedIn") != null) {
			List<String> users = (List<String>) this.getServletContext()
					.getAttribute("usersLoggedIn");

			for (String userName : users) {
				String[] userNamePassword = userName.split(",");

				if (userNamePassword[0].equals(user)
						&& userNamePassword[1].equals(password)) {
					response.sendRedirect("Login");
					return;

				} else if (userNamePassword[0].equals(user)
						&& !userNamePassword[1].equals(password)) {
					//out.println("Invalid Credentials..");
					
					request.getRequestDispatcher("/WEB-INF/InvalidCredentials.jsp").forward(request,
							response);
					return;
				}
			}

		}

		// System.out.println(user + "|" + password);

		if (Ldap.validate(user, password) || Ldap.validate1(user, password)) {

			List<String> users = (List<String>) this.getServletContext()
					.getAttribute("usersLoggedIn");
			
			HttpSession session = request.getSession(false);
			session.setAttribute("userName", user);

			users.add(user + "," + password);

			String ticket = "";

			try {
				ticket = getTrustedTicket(propTab.get("server").toString(),
						user, request.getRemoteAddr());
				if (!ticket.equals("-1")) {
					// System.out.println("" + ticket);
					String url = "http://" + "10.10.10.78" + "/trusted/"
							+ ticket + propTab.get("link");
					// + /* propTab.get("server").toString() *//*
					// "103.241.180.125" */"tableau.crifhighmark.com"

					System.out.println(url);// http://10.10.10.77/trusted/Etdpsm_Ew6rJY-9kRrALjauU/views/workbookQ4/SalesQ4

					out.println(" <iframe src=" + url
							+ " width=\"1335\" height=\"610\"></iframe>");

					request.setAttribute("url", url);
					request.getRequestDispatcher("/TableauP.jsp").forward(
							request, response);

					// response.sendRedirect(url);
				} else {
					out.println("-1");
				}
			} catch (Exception e) {
				out.println("Exception Occured : "
						+ e.getStackTrace().hashCode());
			}
		} else {
			//out.println("Invalid Credentials..");
			request.getRequestDispatcher("/WEB-INF/InvalidCredentials.jsp").forward(request,
					response);
		}
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	private String getTrustedTicket(String wgserver, String user,
			String remoteAddr) throws ServletException {
		OutputStreamWriter out = null;
		BufferedReader in = null;
		try {
			StringBuffer data = new StringBuffer();
			data.append(URLEncoder.encode("username", "UTF-8"));
			data.append("=");
			data.append(URLEncoder.encode(user, "UTF-8"));
			data.append("&");
			data.append(URLEncoder.encode("client_ip", "UTF-8"));
			data.append("=");
			data.append(URLEncoder.encode(remoteAddr, "UTF-8"));
			URL url = new URL("http://" + propTab.get("server").toString()
					+ "/trusted");
			System.out.println(url);
			URLConnection conn = url.openConnection();
			conn.setDoOutput(true);

			out = new OutputStreamWriter(conn.getOutputStream());
			out.write(data.toString());
			out.flush();

			StringBuffer rsp = new StringBuffer();
			in = new BufferedReader(
					new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = in.readLine()) != null) {
				rsp.append(line);
			}
			return rsp.toString();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e);
		} finally {
			try {
				if (in != null)
					in.close();
				if (out != null)
					out.close();
			} catch (IOException e) {
			}
		}
	}

	@Override
	public void destroy() {

		super.destroy();
	}
}