package manager;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LogOut
 */
//@WebServlet("/LogOut")
public class LogOut extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LogOut() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		String userName = (String) session.getAttribute("userName");
		List<String> userNames = (List<String>) this.getServletContext().getAttribute("usersLoggedIn");
		
		Iterator<String> it = userNames.iterator();
		while(it.hasNext()) {
			String user = it.next();
			String [] userNamePassword = user.split(",");
			if (userNamePassword[0].equals(userName)) {
				it.remove();
				break;
			}
		}
		if (session != null) {
			session.invalidate();
		}

		/*
		 * Second step : Invalidate all cookies by, for each cookie received,
		 * overwriting value and instructing browser to deletes it
		 */
		Cookie[] cookies = request.getCookies();
		if (cookies != null && cookies.length > 0) {
			for (Cookie cookie : cookies) {
				cookie.setValue("-");
				cookie.setMaxAge(0);
				response.addCookie(cookie);
			}
		}

		response.setHeader("Cache-Control", "no-cache, no-store");
		response.setHeader("Pragma", "no-cache");
		/*
		 * request.getRequestDispatcher(
		 * "http://10.10.10.77/manual/auth/logout").forward(request, response);
		 */
		// response.sendRedirect("http://10.10.10.77/manual/auth/logout");
		// request.getSession().invalidate();
		this.getServletContext().removeAttribute("LoggedInAlready");
		response.sendRedirect(request.getContextPath() + "/Login.jsp");
		// TODO Auto-generated method stub
	}

}
