package manager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.UnsupportedEncodingException;
import java.util.Properties;
import org.apache.commons.lang.StringUtils;
import com.novell.ldap.LDAPConnection;
import com.novell.ldap.LDAPException;

public class Ldap {

	public static Properties prop = new Properties();

	static {
		try {
			// String proj_Dir = System.getProperty("user.dir");
			// String location = System.getenv("HMROOT");
			// System.out.println(location);
			BufferedReader idFormatReader = new BufferedReader(new FileReader(
					new File("D:\\config\\LdapSettings.properties")));
			// BufferedReader idFormatReader = new BufferedReader(new
			// FileReader(new File(location +
			// "//tableau//config1//LdapSettings.properties")));
			// location + "//tableau//config//LdapSettings.properties"));
			// location + "//config//LdapSettings.properties"));

			// System.out.println(proj_Dir);
			while ((idFormatReader.readLine()) != null) {
				prop.load(idFormatReader);
			}
			idFormatReader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		System.out.println(validate("swati", ""));
	}

	public static boolean validate(String user, String password) {
		System.out.println("Ldap.validate()");
		if (StringUtils.isBlank(password) || StringUtils.isBlank(user)) {
			return false;
		}
		int ldapPort = Integer.parseInt(prop.get("ldapPort").toString());

		int ldapVersion = Integer.parseInt(prop.get("ldapVersion").toString());

		String ldapHost = prop.get("ldapHost").toString();

		//String loginDN = "uid=bdteam,ou=tableau,dc=highmark,dc=in";
         String loginDN = "uid=" + user + "," + prop.get("base");
		// "uid=bdteam,ou=tableau,ou=groups,dc=highmark,dc=in";

		LDAPConnection lc = new LDAPConnection();

		try {
			lc.connect(ldapHost, ldapPort);

			lc.bind(ldapVersion, loginDN, password.getBytes("UTF8"));

			lc.disconnect();
			return true;
		}

		catch (LDAPException e) {

			System.out.println("Error: " + e.toString());
			return false;
		}

		catch (UnsupportedEncodingException e) {

			System.out.println("Error: " + e.toString());
			return false;
		}
	}

	public static boolean validate1(String user, String password) {
		System.out.println("Ldap.validate1()");
		if (StringUtils.isBlank(password) || StringUtils.isBlank(user)) {
			return false;
		}
		int ldapPort = Integer.parseInt(prop.get("ldapPort1").toString());

		int ldapVersion = Integer.parseInt(prop.get("ldapVersion1").toString());

		String ldapHost = prop.get("ldapHost1").toString();

	//	String loginDN = "uid=bdteam,ou=tableau,dc=highmark,dc=in";

		 String loginDN = "uid=" + user + "," + prop.get("base");
		
		// "uid=bdteam,ou=tableau,ou=groups,dc=highmark,dc=in";

		LDAPConnection lc = new LDAPConnection();

		try {

			lc.connect(ldapHost, ldapPort);

			lc.bind(ldapVersion, loginDN, password.getBytes("UTF8"));

			lc.disconnect();
			return true;
		}

		catch (LDAPException e) {

			System.out.println("Error: " + e.toString());
			return false;
		}

		catch (UnsupportedEncodingException e) {

			System.out.println("Error: " + e.toString());
			return false;
		}
	}

}
